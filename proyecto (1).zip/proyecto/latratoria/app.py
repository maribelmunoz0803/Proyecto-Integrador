from flask import Flask, render_template, request, redirect
from psycopg2 import connect, extras

app = Flask(__name__)

# Datos para la conexión a la base de datos
host = "localhost"
port = 5432
username = "postgres"
password = "1602"
dbname = "latratoria"

# Función para la conexión a la base de datos
def connect_database():
    conn = connect(host=host, port=port, user=username, password=password, dbname=dbname)
    return conn

# Ruta raíz - página de inicio
@app.route("/")
def home():
    return render_template("index.html")
# Ruta reserva


# Ruta para el ingreso del administrador
@app.route("/administrador", methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == "latratoria" and password == "1234":
            return redirect('/registro')
        else:
            return render_template("login.html", mostrar_error=True)
    else:
        return render_template('login.html', mostrar_error=False)

# Ruta para el listado de registros
@app.route("/registro", methods=['GET'])
def registros():
    conn = connect_database()
    cursor = conn.cursor(cursor_factory = extras.RealDictCursor)
    cursor.execute("SELECT c.idcedula, c.nombre, c.apellido, c.telefono, c.correo, c.descripciondealergias,a.idambiente,a.nombreambiente, r.idreserva,r.fecha, r.cantidadepersonas FROM comensales c, reservas r, ambientes a WHERE a.idambiente = r.idambiente AND c.idcedula = r.idcedula order by r.fecha ASC")
    datos = cursor.fetchall()
    conn.close()
    cursor.close()
    print(datos)
    return render_template("registro.html", datos=datos)

@app.route("/formulario", methods=["GET"])
#Funcion para plasmar ambientes en la tabla de formulario
def ambientes():
    conn = connect_database()
    cursor= conn.cursor(cursor_factory=extras.RealDictCursor)
    cursor.execute("SELECT idambiente,nombreambiente FROM ambientes")
    ambientes=cursor.fetchall()
    conn.close()
    cursor.close()
    print(ambientes)
    return render_template("formulario.html", ambientes=ambientes)
    
#Ruta para acceder a la reserva
@app.route("/formulario", methods=["GET","POST"])
def reservar():
    return render_template("formulario.html")

#Metodo para eliminar una reserva 
@app.route("/<int:idreserva>/delete", methods=["GET", "POST"])
def eliminar_reserva(idreserva):
    conn=connect_database()
    cursor=conn.cursor(cursor_factory=extras.RealDictCursor)
    cursor.execute("Select a.nombreambiente, c.nombre, c.apellido from reservas r, ambientes a,comensales c where a.idambiente=r.idambiente and c.idcedula=r.idcedula and idreserva=%s",(idreserva,))
    ambientes=cursor.fetchone()
    cursor.execute("Delete from reservas where idreserva=%s RETURNING *",(idreserva,))
    eliminar=cursor.fetchone()
    if request.method == "POST":
        if eliminar:
            conn.commit()
            cursor.close()
            conn.close()
            return redirect("/registro")
    return render_template("delete.html",reservas=eliminar,ambientes=ambientes)

#Ruta para editar un registro
@app.route("/<int:idreserva>/update", methods=["GET", "POST"])
def editar_registro(idreserva):
    conn=connect_database()
    cursor=conn.cursor(cursor_factory=extras.RealDictCursor)
    cursor.execute("Select r.idreserva,r.fecha,r.cantidadepersonas,r.idcedula,r.idambiente, c.nombre, c.apellido from reservas r, comensales c where c.idcedula=r.idcedula and r.idreserva=%s", (idreserva,))
    editar=cursor.fetchone()
    cursor.execute("SELECT idambiente, descripcion, nombreambiente FROM ambientes")
    ambientes=cursor.fetchall()
    cursor.close()
    conn.close()
    if request.method=="POST":
        fecha = request.form["fecha"]
        cantidadepersonas = request.form["cantidadepersonas"]
        idcedula = request.form["idcedula"]
        idambiente = request.form["ida"]
        conn=connect_database()
        cursor=conn.cursor(cursor_factory=extras.RealDictCursor)
        cursor.execute("UPDATE reservas SET fecha=%s, cantidadepersonas=%s, idcedula=%s, idambiente=%s WHERE idreserva=%s RETURNING *",
                   (fecha,cantidadepersonas,idcedula,idambiente,idreserva))
        editado=cursor.fetchone()
        if editado:
            conn.commit()
            cursor.close()
            conn.close()
            return redirect("/registro")
    return render_template("update.html", reserva=editar,ambientes=ambientes)

#Ruta para crear
@app.route("/crear", methods=["GET","POST"])
def crear_comensal():
    if request.method=="GET":
        return render_template("formulario.html")
    if request.method=="POST":
        nombre = request.form["nombre"]
        apellido = request.form["apellido"]
        cedula = request.form["cedula"]
        telefono = request.form["telefono"]
        correo = request.form["correo"]
        alergias = request.form["alergias"]
        conn=connect_database()
        cursor=conn.cursor(cursor_factory=extras.RealDictCursor)
        cursor.execute("INSERT INTO comensales(idcedula,nombre,apellido,telefono,correo,descripciondealergias) VALUES (%s,%s,%s,%s,%s,%s) RETURNING *",
                       (cedula,nombre,apellido,telefono,correo,alergias))
        comensales=cursor.fetchone()
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(f"/formulario2/{cedula}")

@app.route("/formulario2/<int:cedula>", methods=["GET", "POST"])
def crear_reserva(cedula):
    if request.method=="GET":
        conn=connect_database()
        cursor=conn.cursor(cursor_factory=extras.RealDictCursor)
        cursor.execute("SELECT * from ambientes")
        ambientes=cursor.fetchall()
        return render_template("formulario2.html",ambientes=ambientes)
    if request.method=="POST":
        ambiente=request.form["ambiente"]
        fecha=request.form["fecha"]
        cantidad=request.form["cantidad"]
        conn=connect_database()
        cursor=conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM reservas WHERE idambiente=%s AND fecha=%s", (ambiente, fecha))
        validacion=cursor.fetchone()[0]
        if validacion > 0:
            error="Elija otro ambiente u otra fecha."
            return render_template("formulario2.html",mensaje=error)
        else:
            cursor.execute("INSERT INTO reservas (fecha,cantidadepersonas,idcedula,idambiente) VALUES (%s, %s, %s,%s)",
                           (fecha, cantidad,cedula,ambiente))
            conn.commit()
            conn.close()
            cursor.close()
            confirmar="Reservación exitosa."
            return render_template("formulario2.html",mensaje=confirmar)
        

    
       
if __name__ == "__main__":
    app.run(debug=True)